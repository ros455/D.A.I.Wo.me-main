export { Page as default } from './Page'
