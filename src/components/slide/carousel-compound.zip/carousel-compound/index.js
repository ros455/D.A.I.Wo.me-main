export { Carousel as default } from './Carousel'
